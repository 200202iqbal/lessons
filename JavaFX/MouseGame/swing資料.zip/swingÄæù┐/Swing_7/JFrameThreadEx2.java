package Swing7;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class JFrameThreadEx2 extends JFrame {
	int ballX, ballY; // ボールの始点座標（してんざひょう）
	int squareX, squareY;// 　四角の座標
	int width, height; //　ボールの幅、高さ
	int panelWidth, panelHeight; // パネルのサイズ（幅、高さ）
	//	int directionX, directionY; //　XとYの移動方向（いどうほうこう）

	public JFrameThreadEx2() {
		setSize(400, 300);
		setTitle("スレッドのテスト");
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		//ボールの初期位置（しょきいち）を決める
		ballX = 100;
		ballY = 100;
		//四角の初期位置（しょきいち）を決める
		squareX = 80;
		squareY = 40;
		//ボールと四角のサイズを決める
		width = 20;
		height = 20;

		Container cont = getContentPane();
		ThreadPanel2 panel = new ThreadPanel2();
		cont.add(panel);

		// ボールを動かす
		BallThread ballthread = new BallThread(this);
		ballthread.start();
		// 四角を動かす
		SquareThread squarethread = new SquareThread(this);
		squarethread.start();
	}

	public static void main(String[] args) {
		JFrame frame = new JFrameThreadEx2();
		frame.setVisible(true);
	}

	/**  部品(ぶひん）を動（うご）かすメソッド */

	class ThreadPanel2 extends JPanel {
		public ThreadPanel2() {
			setBackground(Color.PINK);
		}

		@Override
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			// パネルの幅と高（はばとたか）さを取得（しゅとく）する
			Dimension d = getSize();
			panelWidth = d.width;
			panelHeight = d.height;

			// ボールを作成する
			g.setColor(Color.BLUE);
			g.fillOval(ballX, ballY, width, height);

			//　四角を作成する
			g.setColor(Color.RED);
			g.fillRect(squareX, squareY, width, height);
		}
	}

	//スレッドクラスを作成する
	// ボールを動カスクラス
	class BallThread extends Thread implements Runnable {
		public BallThread(Container p) {
			super();
		}

		@Override
		public void run() {
			// 移動距離（いどうきょり）を決）き）める
			int moveX = 2;
			int moveY = 2;
			//ボールの移動方向（いどうほうこう）をきめる
			int directionX = 1; // x方向(1:→ 1: ←)
			int directionY = 1; // ｙ方向(1:↓ 1: ↑)
			// 無限（むげん）ループさせる
			while (true) {
				// 移動速度（いどうそくど）をきめる　
				try {
					Thread.sleep(30); // スレッドのスリープ時間を20msに
				} catch (Exception e) {
					// 処理はなし
				}
				// X、Yの移動する方向を決める
				ballX += moveX * directionX;
				ballY += moveY * directionY;
				//　画面の左or右の端（はし）に来たら符号（ふごう）を反転（はんてん）させる
				if (ballX < 0 || ballX > panelWidth - width) {
					directionX *= -1;
				}
				if (ballY < 0 || ballY > panelHeight - height) {
					directionY *= -1;
				}
				repaint();
			}
		}
	}
	// 四角を動かすクラス
	class SquareThread extends Thread implements Runnable {
		public SquareThread(Container p) {
			super();
		}

		@Override
		public void run() {
			// 移動距離（いどうきょり）を決）き）める
			int moveX =3;
			int moveY =1;
			//ボールの移動方向（いどうほうこう）をきめる
			int directionX = -1; // x方向(1:→ 1: ←)
			int directionY = -1; // ｙ方向(1:↓ 1: ↑)
			// 無限（むげん）ループさせる
			while (true) {
				// 移動速度（いどうそくど）をきめる　
				try {
					Thread.sleep(30); // スレッドのスリープ時間を20msに
				} catch (Exception e) {
					// 処理はなし
				}
				// X、Yの移動する方向を決める
				squareX += moveX * directionX;
				squareY += moveY * directionY;
				//　画面の左or右の端（はし）に来たら符号（ふごう）を反転（はんてん）させる
				if (squareX < 0 || squareX > panelWidth - width) {
					directionX *= -1;
				}
				if (squareY < 0 || squareY > panelHeight - height) {
					directionY *= -1;
				}
				repaint();
			}
		}
	}
}
